# GitHub Dashboard — sn875762-gif

A responsive, dark-mode dashboard for your GitHub account.

## Run it
1. Download and extract `github-dashboard-sn875762-gif.zip`.
2. Open `index.html` in a modern browser. If your browser blocks API requests from local files, run a local server in this folder:
   - Python: `python -m http.server 8000`
   - Then open `http://localhost:8000`

## Publish with GitHub Pages
1. Create a public repository, for example `github-dashboard`.
2. Upload `index.html` and this README.
3. In the repository, open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.

The dashboard fetches public profile and repository data from GitHub's unauthenticated REST API when opened. It does not request or store your password or personal access token. Private repositories and private activity are not shown. Unauthenticated API requests are rate-limited by GitHub.
